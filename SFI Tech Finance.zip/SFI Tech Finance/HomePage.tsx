'use client'

import { useState } from 'react'
import { ArrowRight, CreditCard, Smartphone, Zap } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  const [isRedirecting, setIsRedirecting] = useState(false)

  const handleDemoClick = () => {
    setIsRedirecting(true)
    // In a real application, you would use Next.js routing here
    setTimeout(() => {
      window.location.href = '/demo'
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">FlashPay</h1>
          <Button onClick={handleDemoClick} disabled={isRedirecting}>
            {isRedirecting ? 'Redirecting...' : 'Try Demo'}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <section className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Welcome to the Future of Banking
          </h2>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Experience seamless financial management with FlashPay's cutting-edge neo banking platform.
          </p>
        </section>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2 h-5 w-5 text-indigo-500" />
                Smart Cards
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Manage your FlashPay debit and credit cards with real-time updates, instant freezing, and smart spending insights.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Smartphone className="mr-2 h-5 w-5 text-indigo-500" />
                UPI Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Generate dynamic QR codes for instant UPI payments, making transactions faster and more secure than ever.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-indigo-500" />
                Real-Time Banking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Experience the power of real-time transactions, balance updates, and financial insights at your fingertips.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <Button size="lg" onClick={handleDemoClick} disabled={isRedirecting}>
            {isRedirecting ? 'Preparing Your Demo...' : 'Experience FlashPay Now'}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </main>

      <footer className="bg-white mt-16">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
          <div className="flex justify-center space-x-6 md:order-2">
            <a href="#" className="text-gray-400 hover:text-gray-500">
              About
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Contact
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Privacy
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Terms
            </a>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-base text-gray-400">
              &copy; 2024 FlashPay. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}