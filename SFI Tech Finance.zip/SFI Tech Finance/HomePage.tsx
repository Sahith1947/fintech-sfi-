'use client'

import { useState } from 'react'
import { QrCode, CreditCard, BarChart2, ArrowRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function HomePage() {
  const [upiId, setUpiId] = useState('')
  const [qrCode, setQrCode] = useState('')

  const generateQRCode = () => {
    // In a real application, this would call an API to generate the QR code
    setQrCode(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${upiId}`)
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">SFI Tech Finance</h1>
          <Button variant="outline">Demo</Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <QrCode className="mr-2" /> UPI QR Code Generator
              </CardTitle>
              <CardDescription>Generate a QR code for instant payments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="Enter UPI ID"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
                <Button onClick={generateQRCode}>Generate</Button>
              </div>
              {qrCode && (
                <div className="mt-4 flex justify-center">
                  <img src={qrCode} alt="QR Code" className="border-2 border-gray-200 rounded-lg" />
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart2 className="mr-2" /> Current Account
              </CardTitle>
              <CardDescription>Manage your account and view transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-4">Balance: ₹50,000.00</div>
              <Tabs defaultValue="transactions">
                <TabsList>
                  <TabsTrigger value="transactions">Transactions</TabsTrigger>
                  <TabsTrigger value="details">Account Details</TabsTrigger>
                </TabsList>
                <TabsContent value="transactions">
                  <ul className="space-y-2">
                    <li className="flex justify-between items-center">
                      <span>Payment to XYZ Ltd</span>
                      <span className="text-red-500">-₹1,500.00</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <span>Deposit from ABC Corp</span>
                      <span className="text-green-500">+₹3,000.00</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <span>Utility Bill Payment</span>
                      <span className="text-red-500">-₹500.00</span>
                    </li>
                  </ul>
                </TabsContent>
                <TabsContent value="details">
                  <div className="space-y-2">
                    <p><strong>Account Number:</strong> XXXX XXXX 1234</p>
                    <p><strong>IFSC Code:</strong> SFIF0001234</p>
                    <p><strong>Account Type:</strong> Current</p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2" /> FlashPay Card
              </CardTitle>
              <CardDescription>Manage your FlashPay debit and credit cards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl p-6 text-white">
                  <h3 className="text-xl font-semibold mb-4">FlashPay Debit</h3>
                  <p className="text-sm mb-2">Card Number: **** **** **** 5678</p>
                  <p className="text-sm mb-2">Valid Thru: 12/25</p>
                  <p className="text-lg font-bold mt-4">Balance: ₹25,000.00</p>
                </div>
                <div className="bg-gradient-to-r from-pink-500 to-red-600 rounded-xl p-6 text-white">
                  <h3 className="text-xl font-semibold mb-4">FlashPay Credit</h3>
                  <p className="text-sm mb-2">Card Number: **** **** **** 9012</p>
                  <p className="text-sm mb-2">Valid Thru: 06/26</p>
                  <p className="text-lg font-bold mt-4">Available Credit: ₹75,000.00</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Tabs defaultValue="transactions" className="w-full">
                <TabsList>
                  <TabsTrigger value="transactions">Recent Transactions</TabsTrigger>
                  <TabsTrigger value="limits">Spending Limits</TabsTrigger>
                  <TabsTrigger value="rewards">Rewards</TabsTrigger>
                </TabsList>
                <TabsContent value="transactions">
                  <ul className="space-y-2">
                    <li className="flex justify-between items-center">
                      <span>Online Shopping</span>
                      <span className="text-red-500">-₹2,500.00</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <span>Restaurant Payment</span>
                      <span className="text-red-500">-₹1,200.00</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <span>Fuel Purchase</span>
                      <span className="text-red-500">-₹3,000.00</span>
                    </li>
                  </ul>
                </TabsContent>
                <TabsContent value="limits">
                  <div className="space-y-2">
                    <p><strong>Daily ATM Withdrawal:</strong> ₹50,000</p>
                    <p><strong>Daily Online Transaction:</strong> ₹1,00,000</p>
                    <p><strong>Monthly Credit Limit:</strong> ₹2,00,000</p>
                  </div>
                </TabsContent>
                <TabsContent value="rewards">
                  <div className="space-y-2">
                    <p><strong>Cashback Earned:</strong> ₹500</p>
                    <p><strong>Reward Points:</strong> 2,500</p>
                    <p><strong>Next Milestone:</strong> 5,000 points for ₹1,000 cashback</p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  )
}