'use client'

import { useState, useEffect } from 'react'
import { ArrowRight, ArrowLeft, Bell, CreditCard, Smartphone, Zap, ChevronRight, Eye, EyeOff, Settings } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function FlashPayApp() {
  const [showDemo, setShowDemo] = useState(false)
  const [balance, setBalance] = useState(5000)
  const [creditLimit, setCreditLimit] = useState(10000)
  const [creditUsed, setCreditUsed] = useState(2500)
  const [showBalance, setShowBalance] = useState(true)
  const [upiId, setUpiId] = useState('')
  const [qrCode, setQrCode] = useState('')
  const [transactions, setTransactions] = useState([
    { id: 1, description: 'Grocery Store', amount: -75.50, date: '2024-03-15' },
    { id: 2, description: 'Salary Deposit', amount: 3000, date: '2024-03-14' },
    { id: 3, description: 'Electric Bill', amount: -120, date: '2024-03-13' },
  ])

  useEffect(() => {
    if (showDemo) {
      const timer = setInterval(() => {
        setBalance(prevBalance => prevBalance + (Math.random() > 0.5 ? 1 : -1) * Math.random() * 10)
        setCreditUsed(prevUsed => Math.max(0, Math.min(creditLimit, prevUsed + (Math.random() > 0.5 ? 1 : -1) * Math.random() * 50)))
      }, 5000)
      return () => clearInterval(timer)
    }
  }, [showDemo, creditLimit])

  const generateQRCode = () => {
    setQrCode(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${upiId}`)
  }

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount)
  }

  const HomePage = () => (
    <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">FlashPay</h1>
          <Button onClick={() => setShowDemo(true)}>
            Try Demo
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <section className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Welcome to the Future of Banking
          </h2>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Experience seamless financial management with FlashPay's cutting-edge neo banking platform.
          </p>
        </section>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2 h-5 w-5 text-indigo-500" />
                Smart Cards
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Manage your FlashPay debit and credit cards with real-time updates, instant freezing, and smart spending insights.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Smartphone className="mr-2 h-5 w-5 text-indigo-500" />
                UPI Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Generate dynamic QR codes for instant UPI payments, making transactions faster and more secure than ever.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-indigo-500" />
                Real-Time Banking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Experience the power of real-time transactions, balance updates, and financial insights at your fingertips.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <Button size="lg" onClick={() => setShowDemo(true)}>
            Experience FlashPay Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </main>

      <footer className="bg-white mt-16">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
          <div className="flex justify-center space-x-6 md:order-2">
            <a href="#" className="text-gray-400 hover:text-gray-500">
              About
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Contact
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Privacy
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Terms
            </a>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-base text-gray-400">
              &copy; 2024 FlashPay. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )

  const DemoPage = () => (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="mr-4" onClick={() => setShowDemo(false)}>
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h1 className="text-2xl font-bold text-indigo-600">FlashPay Demo</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-6 w-6" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder-avatar.jpg" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Current Balance</span>
                <Button variant="ghost" size="icon" onClick={() => setShowBalance(!showBalance)}>
                  {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold mb-4">
                {showBalance ? formatCurrency(balance) : '••••••'}
              </div>
              <div className="flex justify-between items-center">
                <Button>Send Money</Button>
                <Button>Request Money</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Smartphone className="mr-2" /> UPI Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2 mb-4">
                <Input
                  type="text"
                  placeholder="Enter UPI ID"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
                <Button onClick={generateQRCode}>Generate</Button>
              </div>
              {qrCode && (
                <div className="flex justify-center">
                  <img src={qrCode} alt="QR Code" className="border-2 border-gray-200 rounded-lg" />
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {transactions.map(transaction => (
                  <li key={transaction.id} className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{transaction.description}</p>
                      <p className="text-sm text-gray-500">{transaction.date}</p>
                    </div>
                    <span className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                      {formatCurrency(transaction.amount)}
                    </span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">View All Transactions</Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2" /> FlashPay Card
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="debit">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="debit">Debit</TabsTrigger>
                  <TabsTrigger value="credit">Credit</TabsTrigger>
                </TabsList>
                <TabsContent value="debit">
                  <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white mb-4">
                    <p className="text-sm mb-1">FlashPay Debit</p>
                    <p className="text-lg font-bold mb-4">**** **** **** 5678</p>
                    <p className="text-sm">Valid Thru: 12/25</p>
                  </div>
                  <Button variant="outline" className="w-full">Manage Card</Button>
                </TabsContent>
                <TabsContent value="credit">
                  <div className="bg-gradient-to-r from-pink-500 to-red-600 rounded-xl p-6 text-white mb-4">
                    <p className="text-sm mb-1">FlashPay Credit</p>
                    <p className="text-lg font-bold mb-4">**** **** **** 9012</p>
                    <p className="text-sm">Valid Thru: 06/26</p>
                  </div>
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Credit Used</span>
                      <span>{formatCurrency(creditUsed)} / {formatCurrency(creditLimit)}</span>
                    </div>
                    <Progress value={(creditUsed / creditLimit) * 100} />
                  </div>
                  <Button variant="outline" className="w-full">Manage Card</Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="bg-white mt-16">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
          <div className="flex justify-center space-x-6 md:order-2">
            <Button variant="ghost">Help</Button>
            <Button variant="ghost">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-sm text-gray-400">
              This is a demo version. No real transactions are processed.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )

  return showDemo ? <DemoPage /> : <HomePage />
}