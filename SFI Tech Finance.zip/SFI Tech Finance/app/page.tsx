'use client'

import { useState } from 'react'
import { ArrowRight, CreditCard, Smartphone, Zap, Building, FileText, Briefcase, ShieldCheck } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const HomePage = ({ setShowDemo }) => (
  <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200">
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-indigo-600">FlashPay for Merchants</h1>
        <Button onClick={() => setShowDemo(true)}>
          Try Demo
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </header>

    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <section className="text-center mb-16">
        <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
          Empower Your Business with Modern Banking
        </h2>
        <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
          FlashPay offers cutting-edge financial solutions tailored for merchants and businesses of all sizes.
        </p>
      </section>

      <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="mr-2 h-5 w-5 text-indigo-500" />
              Business Cards
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Manage your business expenses with our smart debit and credit cards. Enjoy cashback, expense tracking, and customizable limits.
            </CardDescription>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Smartphone className="mr-2 h-5 w-5 text-indigo-500" />
              Seamless Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Accept payments via UPI, cards, and more. Generate dynamic QR codes for instant transactions and streamlined bookkeeping.
            </CardDescription>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="mr-2 h-5 w-5 text-indigo-500" />
              Real-Time Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Gain valuable insights into your business with real-time transaction data, cash flow analysis, and financial forecasting.
            </CardDescription>
          </CardContent>
        </Card>
      </div>

      <section className="mt-16">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Why Choose FlashPay for Your Business?</h3>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="mr-2 h-5 w-5 text-green-500" />
                Zero Balance Account
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Open a zero balance current account with no minimum balance requirements. Enjoy full-fledged banking features without the pressure of maintaining a minimum balance.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Briefcase className="mr-2 h-5 w-5 text-blue-500" />
                Business Tools
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Access a suite of business tools including invoicing, payroll management, and tax calculation assistance to streamline your operations.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShieldCheck className="mr-2 h-5 w-5 text-purple-500" />
                Enhanced Security
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Protect your business with advanced fraud detection, real-time alerts, and the ability to instantly freeze/unfreeze your cards for ultimate control.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mt-16 bg-indigo-100 rounded-lg p-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Open Your Current Account Today</h3>
        <p className="text-lg text-gray-700 mb-6">
          To open a current account with FlashPay, you'll need to provide the following KYC documents:
        </p>
        <ul className="list-disc pl-5 space-y-2 text-gray-700">
          <li>PAN Card</li>
          <li>Aadhaar Card</li>
          <li>GST Registration Certificate (for businesses with turnover above ₹20 lakhs)</li>
          <li>Company Registration Documents (for registered companies)</li>
          <li>Proof of Business Address</li>
          <li>Passport-sized photographs of authorized signatories</li>
        </ul>
        <p className="mt-4 text-gray-700">
          The exact requirements may vary based on your business type. Our team will guide you through the process.
        </p>
      </section>

      <section className="mt-16">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5 text-indigo-500" />
              Business Loans
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              <p className="text-lg font-semibold mb-2">Coming Soon!</p>
              We're working on bringing you flexible business loan options to fuel your growth. Stay tuned for updates on our upcoming loan products tailored for merchants and small businesses.
            </CardDescription>
          </CardContent>
          <CardFooter>
            <Button variant="outline">Get Notified</Button>
          </CardFooter>
        </Card>
      </section>

      <div className="mt-16 text-center">
        <Button size="lg" onClick={() => setShowDemo(true)}>
          Experience FlashPay Now
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </main>

    <footer className="bg-white mt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
        <div className="flex justify-center space-x-6 md:order-2">
          <a href="#" className="text-gray-400 hover:text-gray-500">
            About
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Contact
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Privacy
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Terms
          </a>
        </div>
        <div className="mt-8 md:mt-0 md:order-1">
          <p className="text-center text-base text-gray-400">
            &copy; 2024 FlashPay. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  </div>
)

export default function FlashPayApp() {
  const [showDemo, setShowDemo] = useState(false)
  
  // ... (rest of the FlashPayApp component remains unchanged)

  return showDemo ? <DemoPage /> : <HomePage setShowDemo={setShowDemo} />
}