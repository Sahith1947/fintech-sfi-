'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Bell, CreditCard, Smartphone, Zap, ChevronRight, Eye, EyeOff, Settings, Shield, Percent, Gift, Building, FileText, Briefcase, ShieldCheck } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function FlashPayApp() {
  // ... (previous state and functions remain unchanged)

  const DemoPage = () => {
    // ... (previous state declarations remain unchanged)
    const [upiId, setUpiId] = useState('')
    const [qrCode, setQrCode] = useState('')
    const [upiError, setUpiError] = useState('')

    // ... (previous handler functions remain unchanged)

    const validateAndGenerateQR = (id) => {
      // Basic UPI ID validation regex
      const upiRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/
      if (upiRegex.test(id)) {
        setUpiError('')
        // Generate QR code using a UPI payment link
        const upiPaymentLink = `upi://pay?pa=${id}&pn=FlashPay&mc=0000&tid=0000&tr=0000&tn=FlashPay%20Payment`
        setQrCode(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiPaymentLink)}`)
      } else {
        setUpiError('Invalid UPI ID format')
        setQrCode('')
      }
    }

    useEffect(() => {
      if (upiId) {
        validateAndGenerateQR(upiId)
      } else {
        setQrCode('')
        setUpiError('')
      }
    }, [upiId])

    return (
      <div className="min-h-screen bg-gradient-to-b from-teal-50 to-teal-100">
        <header className="bg-teal-700 text-white shadow-lg sticky top-0 z-10">
          {/* ... (header content remains unchanged) */}
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {showSuccessAlert && (
            <Alert className="mb-4 bg-green-100 border-green-400 text-green-700">
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>
                Your credit limit increase request has been submitted successfully. Our bank team will review it shortly.
              </AlertDescription>
            </Alert>
          )}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-2 bg-white shadow-xl">
              {/* ... (Current Balance card content remains unchanged) */}
            </Card>

            <Card className="bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center text-teal-700">
                  <Smartphone className="mr-2" /> UPI Payments
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Input
                      type="text"
                      placeholder="Enter UPI ID (e.g., name@upi)"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className={upiError ? 'border-red-500' : ''}
                    />
                    {upiError && <p className="text-red-500 text-sm mt-1">{upiError}</p>}
                  </div>
                  {qrCode && (
                    <div className="flex flex-col items-center">
                      <img src={qrCode} alt="UPI QR Code" className="border-2 border-teal-200 rounded-lg max-w-full h-auto" />
                      <p className="text-sm text-teal-600 mt-2">Scan to pay via UPI</p>
                    </div>
                  )}
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="w-full bg-teal-600 text-white hover:bg-teal-500">Collect Payment</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Collect Payment</DialogTitle>
                        <DialogDescription>
                          Enter the details to collect payment.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="collectAmount" className="text-right">
                            Amount
                          </Label>
                          <Input
                            id="collectAmount"
                            type="number"
                            className="col-span-3"
                            value={collectAmount}
                            onChange={(e) => setCollectAmount(e.target.value)}
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="collectFrom" className="text-right">
                            From
                          </Label>
                          <Input
                            id="collectFrom"
                            className="col-span-3"
                            value={collectFrom}
                            onChange={(e) => setCollectFrom(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={handleCollectPayment} className="bg-teal-600 text-white hover:bg-teal-500">Collect</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>

            {/* ... (remaining cards and content remain unchanged) */}
          </div>
        </main>

        <footer className="bg-teal-800 text-white mt-16">
          {/* ... (footer content remains unchanged) */}
        </footer>
      </div>
    )
  }

  return showDemo ? <DemoPage /> : <HomePage />
}