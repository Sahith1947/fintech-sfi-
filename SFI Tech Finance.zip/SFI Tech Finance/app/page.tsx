'use client'

import { useState, useEffect } from 'react'
import { ArrowRight, ArrowLeft, Bell, CreditCard, Smartphone, Zap, ChevronRight, Eye, EyeOff, Settings, Shield, Percent, Gift } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export default function FlashPayApp() {
  const [showDemo, setShowDemo] = useState(false)
  const [balance, setBalance] = useState(100000) // 1 lakh rupees
  const [creditLimit, setCreditLimit] = useState(200000)
  const [creditUsed, setCreditUsed] = useState(50000)
  const [showBalance, setShowBalance] = useState(true)
  const [upiId, setUpiId] = useState('')
  const [qrCode, setQrCode] = useState('')
  const [transactions, setTransactions] = useState([
    { id: 1, description: 'Grocery Store', amount: -1500, date: '2024-03-15' },
    { id: 2, description: 'Salary Deposit', amount: 50000, date: '2024-03-14' },
    { id: 3, description: 'Electric Bill', amount: -2000, date: '2024-03-13' },
  ])

  useEffect(() => {
    if (upiId) {
      setQrCode(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${upiId}`)
    } else {
      setQrCode('')
    }
  }, [upiId])

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount)
  }

  // HomePage component remains unchanged

  const DemoPage = () => {
    const [activeCard, setActiveCard] = useState('debit')
    const [sendAmount, setSendAmount] = useState('')
    const [sendTo, setSendTo] = useState('')
    const [requestAmount, setRequestAmount] = useState('')
    const [requestFrom, setRequestFrom] = useState('')
    const [debitCardFrozen, setDebitCardFrozen] = useState(false)
    const [creditCardFrozen, setCreditCardFrozen] = useState(false)
    const [dailyLimit, setDailyLimit] = useState(10000)

    const handleSendMoney = () => {
      const amount = parseFloat(sendAmount)
      if (isNaN(amount) || amount <= 0 || amount > balance) {
        alert('Invalid amount')
        return
      }
      setBalance(prevBalance => prevBalance - amount)
      const newTransaction = {
        id: Date.now(),
        description: `Sent to ${sendTo}`,
        amount: -amount,
        date: new Date().toISOString().split('T')[0]
      }
      setTransactions(prev => [newTransaction, ...prev.slice(0, 4)])
      setSendAmount('')
      setSendTo('')
      alert(`${formatCurrency(amount)} sent to ${sendTo} successfully!`)
    }

    const handleRequestMoney = () => {
      const amount = parseFloat(requestAmount)
      if (isNaN(amount) || amount <= 0) {
        alert('Invalid amount')
        return
      }
      const newTransaction = {
        id: Date.now(),
        description: `Requested from ${requestFrom}`,
        amount: amount,
        date: new Date().toISOString().split('T')[0],
        status: 'Pending'
      }
      setTransactions(prev => [newTransaction, ...prev.slice(0, 4)])
      setRequestAmount('')
      setRequestFrom('')
      alert(`${formatCurrency(amount)} requested from ${requestFrom} successfully!`)
    }

    const handleCardFreeze = (cardType) => {
      if (cardType === 'debit') {
        setDebitCardFrozen(!debitCardFrozen)
      } else {
        setCreditCardFrozen(!creditCardFrozen)
      }
      alert(`${cardType.charAt(0).toUpperCase() + cardType.slice(1)} card ${debitCardFrozen ? 'unfrozen' : 'frozen'} successfully!`)
    }

    const handleDailyLimitChange = (newLimit) => {
      setDailyLimit(newLimit)
      alert(`Daily limit set to ${formatCurrency(newLimit)}`)
    }

    const handleCreditLimitChange = (newLimit) => {
      setCreditLimit(newLimit)
      alert(`Credit limit change request submitted for ${formatCurrency(newLimit)}`)
    }

    return (
      <div className="min-h-screen bg-gray-100">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <Button variant="ghost" size="icon" className="mr-4" onClick={() => setShowDemo(false)}>
                <ArrowLeft className="h-6 w-6" />
              </Button>
              <h1 className="text-2xl font-bold text-indigo-600">FlashPay Demo</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-6 w-6" />
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder-avatar.jpg" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Current Balance</span>
                  <Button variant="ghost" size="icon" onClick={() => setShowBalance(!showBalance)}>
                    {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold mb-4">
                  {showBalance ? formatCurrency(balance) : '••••••'}
                </div>
                <div className="flex justify-between items-center">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>Send Money</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Send Money</DialogTitle>
                        <DialogDescription>
                          Enter the details to send money.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="amount" className="text-right">
                            Amount
                          </Label>
                          <Input
                            id="amount"
                            type="number"
                            className="col-span-3"
                            value={sendAmount}
                            onChange={(e) => setSendAmount(e.target.value)}
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="recipient" className="text-right">
                            To
                          </Label>
                          <Input
                            id="recipient"
                            className="col-span-3"
                            value={sendTo}
                            onChange={(e) => setSendTo(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={handleSendMoney}>Send</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>Request Money</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Request Money</DialogTitle>
                        <DialogDescription>
                          Enter the details to request money.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="requestAmount" className="text-right">
                            Amount
                          </Label>
                          <Input
                            id="requestAmount"
                            type="number"
                            className="col-span-3"
                            value={requestAmount}
                            onChange={(e) => setRequestAmount(e.target.value)}
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="requestFrom" className="text-right">
                            From
                          </Label>
                          <Input
                            id="requestFrom"
                            className="col-span-3"
                            value={requestFrom}
                            onChange={(e) => setRequestFrom(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={handleRequestMoney}>Request</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Smartphone className="mr-2" /> UPI Payments
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Input
                    type="text"
                    placeholder="Enter UPI ID"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                  />
                  {qrCode && (
                    <div className="flex justify-center">
                      <img src={qrCode} alt="QR Code" className="border-2 border-gray-200 rounded-lg" />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {transactions.map(transaction => (
                    <li key={transaction.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-gray-500">{transaction.date}</p>
                      </div>
                      <span className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                        {formatCurrency(Math.abs(transaction.amount))}
                        {transaction.status && ` (${transaction.status})`}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">View All Transactions</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="mr-2" /> FlashPay Card
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="debit" onValueChange={setActiveCard}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="debit">Debit</TabsTrigger>
                    <TabsTrigger value="credit">Credit</TabsTrigger>
                  </TabsList>
                  <TabsContent value="debit">
                    <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white mb-4">
                      <p className="text-sm mb-1">FlashPay Debit</p>
                      <p className="text-lg font-bold mb-4">**** **** **** 5678</p>
                      <p className="text-sm">Valid Thru: 12/25</p>
                    </div>
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Available Balance</span>
                        <span>{formatCurrency(balance)}</span>
                      </div>
                      <Progress value={(balance / 200000) * 100} />
                    </div>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={() => handleCardFreeze('debit')}
                      >
                        {debitCardFrozen ? 'Unfreeze Card' : 'Freeze Card'}
                      </Button>
                      <div className="flex items-center space-x-2">
                        <Input
                          type="number"
                          placeholder="Set Daily Limit"
                          value={dailyLimit}
                          onChange={(e) => handleDailyLimitChange(parseFloat(e.target.value))}
                        />
                        <Button onClick={() => alert(`Daily limit: ${formatCurrency(dailyLimit)}`)}>
                          Set
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="credit">
                    <div className="bg-gradient-to-r from-pink-500 to-red-600 rounded-xl p-6 text-white mb-4">
                      <p className="text-sm mb-1">FlashPay Credit</p>
                      <p className="text-lg font-bold mb-4">**** **** **** 9012</p>
                      <p className="text-sm">Valid  Thru: 06/26</p>
                    </div>
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Credit Used</span>
                        <span>{formatCurrency(creditUsed)} / {formatCurrency(creditLimit)}</span>
                      </div>
                      <Progress value={(creditUsed / creditLimit) * 100} />
                    </div>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={() => handleCardFreeze('credit')}
                      >
                        {creditCardFrozen ? 'Unfreeze Card' : 'Freeze Card'}
                      </Button>
                      <div className="flex items-center space-x-2">
                        <Input
                          type="number"
                          placeholder="Request Credit Limit Increase"
                          onChange={(e) => handleCreditLimitChange(parseFloat(e.target.value))}
                        />
                        <Button onClick={() => alert('Credit limit increase request submitted')}>
                          Request
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </main>

        <footer className="bg-white mt-16">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
            <div className="flex justify-center space-x-6 md:order-2">
              <Button variant="ghost">Help</Button>
              <Button variant="ghost">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </div>
            <div className="mt-8 md:mt-0 md:order-1">
              <p className="text-center text-sm text-gray-400">
                This is a demo version. No real transactions are processed.
              </p>
            </div>
          </div>
        </footer>
      </div>
    )
  }

  return showDemo ? <DemoPage /> : <HomePage />
}