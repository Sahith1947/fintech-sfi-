const HomePage = () => (
  <div className="min-h-screen bg-gradient-to-b from-gray-100 to-gray-200">
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-indigo-600">FlashPay</h1>
        <Button onClick={() => setShowDemo(true)}>
          Try Demo
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </header>

    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <section className="text-center mb-16">
        <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
          Welcome to the Future of Banking
        </h2>
        <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
          Experience seamless financial management with FlashPay's cutting-edge neo banking platform.
        </p>
      </section>

      <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="mr-2 h-5 w-5 text-indigo-500" />
              Smart Cards
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Manage your FlashPay debit and credit cards with real-time updates, instant freezing, and smart spending insights.
            </CardDescription>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Smartphone className="mr-2 h-5 w-5 text-indigo-500" />
              UPI Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Generate dynamic QR codes for instant UPI payments, making transactions faster and more secure than ever.
            </CardDescription>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="mr-2 h-5 w-5 text-indigo-500" />
              Real-Time Banking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Experience the power of real-time transactions, balance updates, and financial insights at your fingertips.
            </CardDescription>
          </CardContent>
        </Card>
      </div>

      <section className="mt-16">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Discover Our Neo Banking Benefits</h3>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="mr-2 h-5 w-5 text-green-500" />
                Enhanced Security
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Enjoy advanced fraud protection, real-time transaction alerts, and the ability to instantly freeze/unfreeze your cards for ultimate control and peace of mind.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Percent className="mr-2 h-5 w-5 text-blue-500" />
                Cashback Rewards
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Earn 1.5% cashback on all purchases with our FlashPay debit card. For credit card users, enjoy 3% cashback on every spend up to ₹10,000 cashback per month, and up to 5% unlimited cashback with our partner merchants.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Gift className="mr-2 h-5 w-5 text-purple-500" />
                Zero Balance Current Account
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Open a zero balance current account with no minimum balance requirements. Enjoy full-fledged banking features without the pressure of maintaining a minimum balance.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mt-16">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Exclusive FlashPay Card Features</h3>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>FlashPay Debit Card</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>Zero balance current account option</li>
                <li>1.5% cashback on all purchases</li>
                <li>Free ATM withdrawals worldwide</li>
                <li>Instant mobile top-ups and bill payments</li>
                <li>Virtual card for secure online shopping</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>FlashPay Credit Card</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>3% cashback on all spends up to ₹10,000 per month</li>
                <li>Up to 5% unlimited cashback with partner merchants</li>
                <li>Up to 55 days interest-free credit</li>
                <li>Flexible credit limits based on your financial profile</li>
                <li>Complimentary airport lounge access</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      <div className="mt-16 text-center">
        <Button size="lg" onClick={() => setShowDemo(true)}>
          Experience FlashPay Now
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </main>

    <footer className="bg-white mt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
        <div className="flex justify-center space-x-6 md:order-2">
          <a href="#" className="text-gray-400 hover:text-gray-500">
            About
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Contact
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Privacy
          </a>
          <a href="#" className="text-gray-400 hover:text-gray-500">
            Terms
          </a>
        </div>
        <div className="mt-8 md:mt-0 md:order-1">
          <p className="text-center text-base text-gray-400">
            &copy; 2024 FlashPay. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  </div>
)